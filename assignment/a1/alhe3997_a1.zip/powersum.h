/*
--------------------------------------------------
Project: a1q2
File:    powersum.h
Author:  Mehdi Al-heloo
Version: 2025-01-17
--------------------------------------------------
*/

#ifndef POWERSUM_H
#define POWERSUM_H

int power_overflow(int b, int n);
int mypower(int b, int n);
int powersum(int b, int n);

#endif