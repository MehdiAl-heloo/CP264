/*
--------------------------------------------------
Project: a1q1
File:    mychar.h
Author:  Mehdi Al-heloo
Version: 2025-01-16
--------------------------------------------------
*/

#ifndef MYCHAR_H
#define MYCHAR_H

int mytype(char c);
char case_flip(char c);
int digit_to_int(char c);

#endif